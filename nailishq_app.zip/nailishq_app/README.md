# Nailishq 💅 – Personal Order & Stock App

Made for Shruti's Press-on Nails business.  
**No backend. Everything stays on the phone.**

## Features
- **Home** → Big beautiful cards for current/working orders + cute empty state
- **New Order** → Nail type, size, reference photo, make date, dispatch date, address, paid/unpaid, notes + materials used
- **Orders** → Full list of all orders
- **Clients** → Save name, measurements, address → one-tap repeat order
- **Stock** → Track materials, auto-deduct when used in order, low-stock warning

Theme matching your business card (deep pink / magenta).

## How to get the APK

1. Create a **new empty repository** on GitHub
2. Upload **all files and folders** from this project (keep structure same)
3. Go to **Actions** tab
4. Run the workflow **"Build APK"**
5. After ~4 minutes download the APK from Artifacts

### First time tip
If the build fails because of missing `android/` folder, run this once on your laptop (if you have Flutter):

```bash
flutter create .
flutter pub get
```

Then push again. Or just let GitHub Actions try – many times it works.

Interface is fully in **English**.
