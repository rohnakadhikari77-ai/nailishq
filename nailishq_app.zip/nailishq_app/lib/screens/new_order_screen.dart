import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../services/storage_service.dart';
import '../models/order.dart';
import '../models/client.dart';
import '../models/stock_item.dart';

class NewOrderScreen extends StatefulWidget {
  final Order? existing;
  final Client? prefillClient;

  const NewOrderScreen({super.key, this.existing, this.prefillClient});

  @override
  State<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends State<NewOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _clientName;
  late TextEditingController _nailType;
  late TextEditingController _size;
  late TextEditingController _price;
  late TextEditingController _notes;
  late TextEditingController _address;

  DateTime? _makeDate;
  DateTime? _dispatchDate;
  String _payment = 'Unpaid';
  String _status = 'Working';
  String? _photoPath;
  String? _selectedClientId;

  List<Client> _clients = [];
  List<StockItem> _stock = [];
  final Map<String, int> _usedMaterials = {};

  bool get isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final o = widget.existing;
    final c = widget.prefillClient;

    _clientName = TextEditingController(text: o?.clientName ?? c?.name ?? '');
    _nailType = TextEditingController(text: o?.nailType ?? '');
    _size = TextEditingController(text: o?.size ?? c?.measurements ?? '');
    _price = TextEditingController(text: o != null ? o.price.toString() : '');
    _notes = TextEditingController(text: o?.notes ?? '');
    _address = TextEditingController(text: o?.address ?? c?.address ?? '');
    _makeDate = o?.makeDate;
    _dispatchDate = o?.dispatchDate;
    _payment = o?.paymentStatus ?? 'Unpaid';
    _status = o?.status ?? 'Working';
    _photoPath = o?.photoPath;
    _selectedClientId = o?.clientId ?? c?.id;
    if (o != null) _usedMaterials.addAll(o.materialsUsed);

    _clients = StorageService.getClients();
    _stock = StorageService.getStock();
  }

  @override
  void dispose() {
    _clientName.dispose();
    _nailType.dispose();
    _size.dispose();
    _price.dispose();
    _notes.dispose();
    _address.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (x == null) return;

    final dir = await getApplicationDocumentsDirectory();
    final name = 'ref_${DateTime.now().millisecondsSinceEpoch}${p.extension(x.path)}';
    final saved = await File(x.path).copy(p.join(dir.path, name));
    setState(() => _photoPath = saved.path);
  }

  Future<void> _pickDate({required bool isMake}) async {
    final initial = isMake
        ? (_makeDate ?? DateTime.now().add(const Duration(days: 2)))
        : (_dispatchDate ?? DateTime.now().add(const Duration(days: 4)));
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime.now().subtract(const Duration(days: 7)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        if (isMake) {
          _makeDate = picked;
        } else {
          _dispatchDate = picked;
        }
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final price = double.tryParse(_price.text) ?? 0;
    final clientId = _selectedClientId ?? StorageService.newId();

    // if new client name typed and no selected, we can auto-create later if needed
    final order = Order(
      id: isEdit ? widget.existing!.id : StorageService.newId(),
      clientId: clientId,
      clientName: _clientName.text.trim(),
      nailType: _nailType.text.trim(),
      size: _size.text.trim(),
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      price: price,
      createdAt: isEdit ? widget.existing!.createdAt : DateTime.now(),
      makeDate: _makeDate,
      dispatchDate: _dispatchDate,
      paymentStatus: _payment,
      status: _status,
      address: _address.text.trim().isEmpty ? null : _address.text.trim(),
      photoPath: _photoPath,
      materialsUsed: Map.from(_usedMaterials),
    );

    if (isEdit) {
      await StorageService.updateOrder(order);
    } else {
      await StorageService.addOrder(order);
      if (_usedMaterials.isNotEmpty) {
        await StorageService.deductMaterials(_usedMaterials);
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isEdit ? 'Order updated' : 'Order saved 💅'),
          backgroundColor: Colors.green,
        ),
      );
      if (isEdit || widget.prefillClient != null) {
        Navigator.pop(context, true);
      } else {
        // clear form for next
        setState(() {
          _clientName.clear();
          _nailType.clear();
          _size.clear();
          _price.clear();
          _notes.clear();
          _address.clear();
          _makeDate = null;
          _dispatchDate = null;
          _payment = 'Unpaid';
          _status = 'Working';
          _photoPath = null;
          _usedMaterials.clear();
          _selectedClientId = null;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Order' : 'New Order'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Client selector
            if (_clients.isNotEmpty && !isEdit) ...[
              const Text('Select Client (optional)', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedClientId,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.person)),
                items: [
                  const DropdownMenuItem(value: null, child: Text('New Client')),
                  ..._clients.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))),
                ],
                onChanged: (v) {
                  setState(() {
                    _selectedClientId = v;
                    if (v != null) {
                      final c = _clients.firstWhere((e) => e.id == v);
                      _clientName.text = c.name;
                      _address.text = c.address ?? '';
                      if (c.measurements != null && c.measurements!.isNotEmpty) {
                        _size.text = c.measurements!;
                      }
                    }
                  });
                },
              ),
              const SizedBox(height: 16),
            ],

            _field(_clientName, 'Client Name *', Icons.person, required: true),
            _field(_nailType, 'Nail Type *', Icons.brush, required: true, hint: 'Classic French, Custom Art...'),
            _field(_size, 'Size / Measurements *', Icons.straighten, required: true, hint: 'S / M / L or detailed'),
            _field(_price, 'Price (₹)', Icons.currency_rupee, keyboard: TextInputType.number),

            // Photo
            const SizedBox(height: 8),
            const Text('Reference Photo', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                height: 140,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: _photoPath != null && File(_photoPath!).existsSync()
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.file(File(_photoPath!), fit: BoxFit.cover, width: double.infinity),
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo, size: 36, color: Color(0xFFC2185B)),
                          SizedBox(height: 6),
                          Text('Tap to add photo', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 16),
            // Dates
            Row(
              children: [
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.construction, color: Color(0xFFC2185B)),
                    title: Text(_makeDate == null ? 'Make Date' : DateFormat('dd MMM').format(_makeDate!)),
                    onTap: () => _pickDate(isMake: true),
                  ),
                ),
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.local_shipping, color: Color(0xFFC2185B)),
                    title: Text(_dispatchDate == null ? 'Dispatch Date' : DateFormat('dd MMM').format(_dispatchDate!)),
                    onTap: () => _pickDate(isMake: false),
                  ),
                ),
              ],
            ),

            _field(_address, 'Address', Icons.location_on, maxLines: 2),

            const SizedBox(height: 8),
            const Text('Payment', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Row(
              children: ['Unpaid', 'Paid'].map((s) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(s),
                    selected: _payment == s,
                    selectedColor: const Color(0xFFC2185B).withOpacity(0.2),
                    onSelected: (_) => setState(() => _payment = s),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 12),
            const Text('Status', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: ['Working', 'Ready', 'Dispatched', 'Delivered'].map((s) {
                return ChoiceChip(
                  label: Text(s),
                  selected: _status == s,
                  selectedColor: const Color(0xFFC2185B).withOpacity(0.2),
                  onSelected: (_) => setState(() => _status = s),
                );
              }).toList(),
            ),

            // Materials used
            if (_stock.isNotEmpty) ...[
              const SizedBox(height: 20),
              const Text('Materials Used (from Stock)', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              ..._stock.map((item) {
                final qty = _usedMaterials[item.name] ?? 0;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(item.name),
                  subtitle: Text('Available: ${item.quantity} ${item.unit ?? ''}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: qty > 0
                            ? () => setState(() {
                                  if (qty <= 1) {
                                    _usedMaterials.remove(item.name);
                                  } else {
                                    _usedMaterials[item.name] = qty - 1;
                                  }
                                })
                            : null,
                      ),
                      Text('$qty', style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline, color: Color(0xFFC2185B)),
                        onPressed: () => setState(() => _usedMaterials[item.name] = qty + 1),
                      ),
                    ],
                  ),
                );
              }),
            ],

            _field(_notes, 'Notes', Icons.note, maxLines: 3),

            const SizedBox(height: 24),
            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC2185B),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(
                  isEdit ? 'Update Order' : 'Save Order',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController c,
    String label,
    IconData icon, {
    bool required = false,
    TextInputType? keyboard,
    int maxLines = 1,
    String? hint,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextFormField(
        controller: c,
        keyboardType: keyboard,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon, color: const Color(0xFFC2185B)),
        ),
        validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null : null,
      ),
    );
  }
}
