import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../models/stock_item.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  List<StockItem> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => setState(() => _items = StorageService.getStock());

  Future<void> _showItemForm({StockItem? existing}) async {
    final nameC = TextEditingController(text: existing?.name ?? '');
    final qtyC = TextEditingController(text: existing?.quantity.toString() ?? '0');
    final unitC = TextEditingController(text: existing?.unit ?? 'pcs');
    final notesC = TextEditingController(text: existing?.notes ?? '');

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                existing == null ? 'Add Stock Item' : 'Edit Stock',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: nameC,
                decoration: const InputDecoration(labelText: 'Item Name *', prefixIcon: Icon(Icons.inventory)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: qtyC,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Quantity *', prefixIcon: Icon(Icons.numbers)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: unitC,
                decoration: const InputDecoration(labelText: 'Unit', hintText: 'pcs / pack / bottle', prefixIcon: Icon(Icons.scale)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notesC,
                decoration: const InputDecoration(labelText: 'Notes', prefixIcon: Icon(Icons.note)),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC2185B),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () async {
                  if (nameC.text.trim().isEmpty) return;
                  final qty = int.tryParse(qtyC.text) ?? 0;
                  final item = StockItem(
                    id: existing?.id ?? StorageService.newId(),
                    name: nameC.text.trim(),
                    quantity: qty,
                    unit: unitC.text.trim().isEmpty ? null : unitC.text.trim(),
                    notes: notesC.text.trim().isEmpty ? null : notesC.text.trim(),
                  );
                  if (existing == null) {
                    await StorageService.addStockItem(item);
                  } else {
                    await StorageService.updateStockItem(item);
                  }
                  Navigator.pop(ctx, true);
                },
                child: Text(existing == null ? 'Add to Stock' : 'Update'),
              ),
            ],
          ),
        );
      },
    );

    if (result == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stock Tracker'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () => _showItemForm()),
        ],
      ),
      body: _items.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('📦', style: TextStyle(fontSize: 48)),
                  SizedBox(height: 12),
                  Text('Stock is empty', style: TextStyle(color: Colors.grey)),
                  Text('Add tips, glitters, glue etc.', style: TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _items.length,
              itemBuilder: (ctx, i) {
                final item = _items[i];
                final low = item.quantity <= 5;
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: low ? Colors.red.shade100 : const Color(0xFFC2185B).withOpacity(0.15),
                      child: Icon(
                        Icons.inventory_2,
                        color: low ? Colors.red : const Color(0xFFC2185B),
                      ),
                    ),
                    title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: item.notes != null ? Text(item.notes!) : null,
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${item.quantity} ${item.unit ?? ''}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: low ? Colors.red : Colors.black87,
                          ),
                        ),
                        if (low)
                          const Text('Low stock', style: TextStyle(fontSize: 11, color: Colors.red)),
                      ],
                    ),
                    onTap: () => _showItemForm(existing: item),
                    onLongPress: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (d) => AlertDialog(
                          title: const Text('Delete Item?'),
                          content: Text('Remove ${item.name} from stock?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                            TextButton(
                              onPressed: () => Navigator.pop(d, true),
                              child: const Text('Delete', style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await StorageService.deleteStockItem(item.id);
                        _load();
                      }
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showItemForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
