import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../models/client.dart';
import 'new_order_screen.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});

  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  List<Client> _clients = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => setState(() => _clients = StorageService.getClients());

  Future<void> _showClientForm({Client? existing}) async {
    final nameC = TextEditingController(text: existing?.name ?? '');
    final phoneC = TextEditingController(text: existing?.phone ?? '');
    final addressC = TextEditingController(text: existing?.address ?? '');
    final measureC = TextEditingController(text: existing?.measurements ?? '');
    final notesC = TextEditingController(text: existing?.notes ?? '');

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  existing == null ? 'Add Client' : 'Edit Client',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: nameC,
                  decoration: const InputDecoration(labelText: 'Name *', prefixIcon: Icon(Icons.person)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: phoneC,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Phone', prefixIcon: Icon(Icons.phone)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: measureC,
                  decoration: const InputDecoration(
                    labelText: 'Measurements',
                    hintText: 'Thumb 16, Index 14...',
                    prefixIcon: Icon(Icons.straighten),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: addressC,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Icons.location_on)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesC,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'Notes', prefixIcon: Icon(Icons.note)),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFC2185B),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () async {
                    if (nameC.text.trim().isEmpty) return;
                    final client = Client(
                      id: existing?.id ?? StorageService.newId(),
                      name: nameC.text.trim(),
                      phone: phoneC.text.trim().isEmpty ? null : phoneC.text.trim(),
                      address: addressC.text.trim().isEmpty ? null : addressC.text.trim(),
                      measurements: measureC.text.trim().isEmpty ? null : measureC.text.trim(),
                      notes: notesC.text.trim().isEmpty ? null : notesC.text.trim(),
                      createdAt: existing?.createdAt ?? DateTime.now(),
                    );
                    if (existing == null) {
                      await StorageService.addClient(client);
                    } else {
                      await StorageService.updateClient(client);
                    }
                    Navigator.pop(ctx, true);
                  },
                  child: Text(existing == null ? 'Save Client' : 'Update'),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (result == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clients'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () => _showClientForm()),
        ],
      ),
      body: _clients.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('👥', style: TextStyle(fontSize: 48)),
                  SizedBox(height: 12),
                  Text('No clients yet', style: TextStyle(color: Colors.grey)),
                  Text('Tap + to add', style: TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _clients.length,
              itemBuilder: (ctx, i) {
                final c = _clients[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(14),
                    title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (c.phone != null) Text(c.phone!),
                        if (c.measurements != null) ...[
                          const SizedBox(height: 4),
                          Text('📏 ${c.measurements}', style: const TextStyle(fontSize: 13)),
                        ],
                        if (c.address != null) ...[
                          const SizedBox(height: 2),
                          Text('📍 ${c.address}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ],
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.add_shopping_cart, color: Color(0xFFC2185B)),
                      tooltip: 'Quick Order',
                      onPressed: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => NewOrderScreen(prefillClient: c),
                          ),
                        );
                        if (result == true) {
                          // optional refresh
                        }
                      },
                    ),
                    onTap: () => _showClientForm(existing: c),
                    onLongPress: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (d) => AlertDialog(
                          title: const Text('Delete Client?'),
                          content: Text('Remove ${c.name}?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                            TextButton(
                              onPressed: () => Navigator.pop(d, true),
                              child: const Text('Delete', style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await StorageService.deleteClient(c.id);
                        _load();
                      }
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showClientForm(),
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
